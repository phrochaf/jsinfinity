const strings = ['abacaxi', 'maca', 'banana', 'kiwi']

console.log(strings.filter(fruta => fruta.length > 5))
