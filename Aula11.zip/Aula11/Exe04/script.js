const numbers = [1,2,3,4,5,6]

const squared = numbers.map(num => num*num);


for(i in squared){

    console.log(squared[i])
}
