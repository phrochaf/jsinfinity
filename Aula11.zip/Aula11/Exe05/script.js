const arr = ['a', 'b', 'c', 'd', 'e', 'f']

function tornarMaiuscula(elemento, indice, array){
    return elemento.toUpperCase()
}

const newarr = arr.map(tornarMaiuscula)

console.log(newarr)