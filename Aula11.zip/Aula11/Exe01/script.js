const numbers = [50, 45, 67, 89, 10, 5]


function myFunction(item, index, arr){
    arr[index] = item*2;
}

numbers.forEach(myFunction)

console.log(numbers)

